#pragma once 

#include <stdint.h>

extern const uint8_t u8g2_font_profont10_tr[];
extern const uint8_t u8g2_font_profont11_tr[];
extern const uint8_t u8g2_font_profont12_tr[];
extern const uint8_t u8g2_font_profont15_tr[];
extern const uint8_t u8g2_font_profont17_tr[];
extern const uint8_t u8g2_font_profont22_tr[];
extern const uint8_t u8g2_font_profont29_tr[];

