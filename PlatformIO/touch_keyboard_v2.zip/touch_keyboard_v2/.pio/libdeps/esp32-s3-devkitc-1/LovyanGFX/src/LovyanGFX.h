#pragma once

#ifdef __cplusplus

#include "LovyanGFX.hpp"

#else

#error LovyanGFX requires a C++ compiler, please change file extension to .cc or .cpp

#endif
